package by.epam.learn.main;

import java.util.Scanner;

class Input {
    int x;

    Input() {
        Scanner scan = new Scanner(System.in);
        x = scan.nextInt();
    }
}
